package com.example.amynita;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.menu_bg);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        iv.setBackgroundColor(0xFF000000);
        iv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() != MotionEvent.ACTION_UP) return true;
                float x = e.getX() / v.getWidth();
                float y = e.getY() / v.getHeight();
                if (x > 0.59f && x < 0.91f) {
                    if (y > 0.45f && y < 0.60f) {          // PLAY
                        finishAffinity();
                        System.exit(0);
                    } else if (y > 0.62f && y < 0.77f) {   // SETTING
                        Toast.makeText(MainActivity.this, "Setting", Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }
        });
        setContentView(iv);
    }
}
